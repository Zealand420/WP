<?php
/*
Plugin Name: Copyright Footer
Plugin URI: if available, I don't have one
Description: Adds a copyright notice in the footer of your site.
Version: 1.0
Author: Nilma Abbas
Author URI: I don't have one :( 
*/

// Function to add copyright notice
function copyright_footer() {
    // Get the current year
    $year = date('Y');
    // Get the name of the site from WordPress settings
    $site_name = get_bloginfo('name');
    // Echo the copyright notice. Modify this line to customize the message.
    echo "<p>&copy; $year $site_name. All rights reserved.</p>";
}

// Hook the 'copyright_footer' function to the 'wp_footer' action
// This tells WordPress to call the copyright_footer function when it's generating the footer.
// The wp_footer action is typically called near the closing body tag in most themes.
add_action('wp_footer', 'copyright_footer');
?>
